/*  Нахождение изначального количества строк и столбцов для каждой матрицы(Глобальные переменные)*/
	var a = document.getElementById("aMatr");	
	var cdivA=a.getElementsByTagName("div");
	var colsA=cdivA.item(0).getElementsByTagName("input").length;
	var rowsA=cdivA.length;
	
	var b = document.getElementById("bMatr");
	var cdivB=b.getElementsByTagName("div");
	var colsB=cdivB.item(0).getElementsByTagName("input").length;
	var rowsB=cdivB.length;
	
	var c = document.getElementById("resultMatr");
	var cdivC=c.getElementsByTagName("div");
	var colsC=cdivC.item(0).getElementsByTagName("input").length;
	var rowsC=cdivC.length;
	placeholder();

document.body.onmouseup=function(){
			var t = document.getElementById("LeftBlock");
		t.style.backgroundColor="#BCBCBC";
		var k = document.getElementById("hide");
		k.style.visibility="hidden";
	
	if (document.getElementById("replace")==document.activeElement) 
	{
		var a = document.getElementById("replace");
	a.style.borderColor="white";
	var b = document.getElementById("ramkar");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("replace");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkar");
	b.style.borderColor="transparent";}
	
	if (document.getElementById("clear")==document.activeElement) 
	{
		
		var a = document.getElementById("clear");
	a.style.borderColor="white";
	var b = document.getElementById("ramkac");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("clear");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkac");
	b.style.borderColor="transparent";}
	
	if (document.getElementById("pm1")==document.activeElement) 
	{
		var a = document.getElementById("pm1");
	a.style.borderColor="white";
	var b = document.getElementById("ramkab1");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("pm1");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkab1");
	b.style.borderColor="transparent";}
	
	if (document.getElementById("pm2")==document.activeElement) 
	{
		var a = document.getElementById("pm2");
	a.style.borderColor="white";
	var b = document.getElementById("ramkab2");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("pm2");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkab2");
	b.style.borderColor="transparent";}
	if (document.getElementById("pmd2")==document.activeElement) 
	{
		var a = document.getElementById("pmd2");
	a.style.borderColor="white";
	var b = document.getElementById("ramkad2");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("pmd2");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkad2");
	b.style.borderColor="transparent";}
		if (document.getElementById("pmd1")==document.activeElement) 
	{
		var a = document.getElementById("pmd1");
	a.style.borderColor="white";
	var b = document.getElementById("ramkad1");
	b.style.borderColor="#5199DB";
	}
	   else {var a = document.getElementById("pmd1");
	a.style.borderColor="rgba(0,0,0,0.4)";
	var b = document.getElementById("ramkad1");
	b.style.borderColor="transparent";}
	
	if (document.getElementById("d")==document.activeElement) 
	{
	var k = document.getElementById("fon1");
	k.style.borderColor="#5199DB";	
	var y = document.getElementById("fon");
	y.style.borderColor="white";
	var c = document.getElementById("testT");
	c.style.backgroundColor="#5199DB";
	var s = document.getElementById("testf");
	s.style.backgroundColor="white";	
	}
	   else {
	var k = document.getElementById("fon1");
	k.style.borderColor="transparent";	
	var y = document.getElementById("fon");
	y.style.borderColor="#919191";
	var c = document.getElementById("testT");
	c.style.backgroundColor="transparent";
	var s = document.getElementById("testf");
	s.style.backgroundColor="#919191";	
	   }
}
function changecolor() {
	var k = document.getElementById("test");
	k.style.backgroundColor="#34830D";	
	var y = document.getElementById("umn");
	y.style.backgroundColor="#34830D";
}
	function changecolorback() {
	var k = document.getElementById("test");
	k.style.backgroundColor="#48A51A";	
	var y = document.getElementById("umn");
	y.style.backgroundColor="#48A51A";
}

function nenajata(){
	var y = document.getElementById("umn");
	y.style.border="none";
}
function najata(){
	var y = document.getElementById("umn");
	y.style.borderTop="2px solid rgba(0,0,0,0.4)";

}


function ReplaceMatr(){	
	var a1 = window.a.innerHTML;
      /*Внесение value матриц в массивы*/
	var arrA=new Array(window.rowsA);
	for (var i=0;i<window.rowsA;i++){
		arrA[i]=new Array(window.colsA);
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			arrA[i][j]=inputOne.item(j).value;				
		}		
	};
	var arrB= new Array(window.rowsB);
	for (var i=0;i<window.rowsB;i++){
		arrB[i]=new Array(window.colsB);
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			arrB[i][j]=inputOne.item(j).value;
		}		
	};	
	window.a.innerHTML=window.b.innerHTML;
	window.b.innerHTML=a1;	
		/*Перерасчет данных */
	window.a = document.getElementById("aMatr");
	window.b = document.getElementById("bMatr");
	window.c = document.getElementById("resultMatr");
	window.cdivA=window.a.getElementsByTagName("div");
	window.colsA=window.cdivA.item(0).getElementsByTagName("input").length;
	window.rowsA=window.cdivA.length;
	window.cdivB=window.b.getElementsByTagName("div");
	window.colsB=window.cdivB.item(0).getElementsByTagName("input").length;
	window.rowsB=window.cdivB.length;
	window.cdivC=window.c.getElementsByTagName("div");
	window.colsC=window.cdivC.item(0).getElementsByTagName("input").length;
	window.rowsC=window.cdivC.length;
	
	for (var i=0;i<window.rowsA;i++){
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			inputOne.item(j).value=arrB[i][j];
			
		}		
	};
		for (var i=0;i<window.rowsB;i++){
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			inputOne.item(j).value=arrA[i][j];
		}		
	};
placeholder();
}

function addstr(){
	var k =document.getElementById("da");
	if (k.checked) {
		if (window.rowsA<10) 
		{		
		var divOne=window.cdivA.item(0);
		var div = document.createElement('div');
		div.innerHTML = divOne.innerHTML;
		window.a.appendChild(div);
		window.a = document.getElementById("aMatr");
		window.cdivA=window.a.getElementsByTagName("div");
		window.rowsA=window.cdivA.length;
		}
		else alert("Матрица А не может иметь больше 10 строк!");
	}
	else if (window.rowsB<10){
		var divOne=window.cdivB.item(0);
		var div = document.createElement('div');
		div.innerHTML = divOne.innerHTML;
		window.b.appendChild(div);
		window.b = document.getElementById("bMatr");
		window.cdivB=window.b.getElementsByTagName("div");
		window.rowsB=window.cdivB.length;
	}
	else alert("Матрица B не может иметь больше 10 строк!");
		
placeholder();
}

function delstr(){
	var k =document.getElementById("da");
	if (k.checked) {
		if (window.rowsA>2) 
		{		
		var divOne=window.cdivA.item(window.rowsA-1);
		
		window.a.removeChild(divOne);
		window.a = document.getElementById("aMatr");
		window.cdivA=window.a.getElementsByTagName("div");
		window.rowsA=window.cdivA.length;
		}
		else alert("Матрица А не может иметь менее 2 строк!");
	}
	else if (window.rowsB>2){
		var divOne=window.cdivB.item(window.rowsB-1);
		
		window.b.removeChild(divOne);
		window.b = document.getElementById("bMatr");
		window.cdivB=window.b.getElementsByTagName("div");
		window.rowsB=window.cdivB.length;
		}
	else alert("Матрица B не может иметь менее 2 строк!");
		
placeholder();
}
function changeColorLeftBlock(){
		var t = document.getElementById("LeftBlock");
		t.style.backgroundColor="#5199DB";
}
var old;
function takethis(input){
	if (input.value>10) {
		input.value="";
		
	}
	else{
		window.old=input.value;
	}
	
}

function numbersonly(input){
	var reg =/[^-0-9.]/gi;
	input.value=input.value.replace(reg,"");
	if (Number(input.value)>10) {
		input.value=window.old;
		alert("Значение должно быть меньше либо равно 10!");
	}
	else {
		window.old=input.value;
	}
}

function umnojenie(){   /* Умножение матриц*/
	if (window.colsA==window.rowsB){     /* Если строки A равно стобцам B*/
	/* Проверка матрицы A*/
	var pr=true;var hi=true;var umn=true;
	for (var i=0;i<window.rowsA;i++){	
		if (hi==false) {break;};
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			if (inputOne.item(j).value=="") {
			pr=false;	
			};					
			if (isNaN(inputOne.item(j).value)) {
				alert("Вы ввели не число!");
				changeColorLeftBlock()
				inputOne.item(j).focus();hi=false;umn=false;break;
			}			
			else if(Number(inputOne.item(j).value)>10){
				alert("Значение должно быть меньше либо равно 10!");
				changeColorLeftBlock()
				inputOne.item(j).focus();hi=false;umn=false;break;
			}
			else if(pr==false){
				alert("Заполните пустую ячейку!");
				changeColorLeftBlock()
				inputOne.item(j).focus();hi=false;umn=false;break;
			}
		}		
	};
	if (umn) {     /* Проверка матрицы B*/
		var pr=true;var hi=true;var umn=true;
	for (var i=0;i<window.rowsB;i++){	
		if (hi==false) {break;};
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			if (inputOne.item(j).value=="") {
			pr=false;	
			};					
			if (isNaN(inputOne.item(j).value)) {
				alert("Вы ввели не число!");
			changeColorLeftBlock();
			inputOne.item(j).focus();hi=false;umn=false;break;
			}			
			else if(Number(inputOne.item(j).value)>10){
				alert("Значение должно быть меньше либо равно 10!");
				changeColorLeftBlock();
				inputOne.item(j).focus();hi=false;umn=false;break;
			}
			else if(pr==false){
				alert("Заполните пустую ячейку!");
				changeColorLeftBlock();inputOne.item(j).focus();hi=false;umn=false;break;
			}
		}		
	};}
	
	
	     /* Если прошло проверку данных в матрицах*/
	if (umn){    
		
	var arrA=new Array(window.rowsA);
	for (var i=0;i<window.rowsA;i++){
		arrA[i]=new Array(window.colsA);
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			arrA[i][j]=inputOne.item(j).value;				
		}		
	};
	var arrB= new Array(window.rowsB);
	for (var i=0;i<window.rowsB;i++){
		arrB[i]=new Array(window.colsB);
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			arrB[i][j]=inputOne.item(j).value;
		}		
	};	
	
		var arrC= new Array(window.rowsA);
		for(var i=0;i<window.rowsA;i++){
			arrC[i]=new Array(window.colsB);
		}
							
		kcolC=arrC[0].length;
		krowC=arrC.length;

			/*Построение матрицы C */
		while(window.colsC<kcolC) {
					
			for (var i=0;i<window.rowsC;i++)
		{
			var e = document.getElementById("one");
			e2=e.cloneNode(true);
			e2.value="";
			var input = e2.cloneNode(true);
			var divOne=window.cdivC.item(i);
			divOne.appendChild(input);
		};	
		
			window.c = document.getElementById("resultMatr");
			window.cdivC=c.getElementsByTagName("div");
			window.colsC=cdivC.item(0).getElementsByTagName("input").length;
			window.rowsC=cdivC.length;

		}
		
		while(window.colsC>kcolC) {
			
			
			for (var i=0;i<window.rowsC;i++){
			var divOne=window.cdivC.item(i);
			lastcell=divOne.childNodes[window.colsC+2];						
			divOne.removeChild(lastcell);
		};
					
			window.c = document.getElementById("resultMatr");
			window.cdivC=c.getElementsByTagName("div");
			window.colsC=cdivC.item(0).getElementsByTagName("input").length;
			window.rowsC=cdivC.length;

		};
		
		
		while(window.rowsC<krowC) {
		
		var divOne=window.cdivC.item(0);
		var div = document.createElement('div');
		div.innerHTML = divOne.innerHTML;
		window.c.appendChild(div);
			
		window.c = document.getElementById("resultMatr");
		window.cdivC=c.getElementsByTagName("div");
		window.colsC=cdivC.item(0).getElementsByTagName("input").length;
		window.rowsC=cdivC.length;
		};
		
		while(window.rowsC>krowC) {	
		var divOne=window.cdivC.item(window.rowsC-1);
		
		window.c.removeChild(divOne);		
		window.c = document.getElementById("resultMatr");
		window.cdivC=c.getElementsByTagName("div");
		window.colsC=cdivC.item(0).getElementsByTagName("input").length;
		window.rowsC=cdivC.length;
		};				
		placeholder();
		
		
		
		for (var i=0;i<window.colsB;i++){
			{
				
				for (j = 0; j < window.rowsA; j++) {				
					var t = 0; 
					for (var k = 0; k < window.rowsB; k++) t += arrA[j][k]*arrB[k][i]; 
					arrC[j][i] = t; 
				}
			}		
		};
			for (var i=0;i<window.rowsA;i++){
		var divOne=window.cdivC.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			inputOne.item(j).value=arrC[i][j];
		}		
		};
	
	};}
	else {
		var t = document.getElementById("LeftBlock");
		t.style.backgroundColor="#F6C1C0";
		var k = document.getElementById("hide");
		k.style.visibility="visible";
	}		
}


function addstolbec(){  /* Добавление столбца*/
	var k =document.getElementById("da");
	if (k.checked) {
		if (window.colsA<10) 
		{		
		for (var i=0;i<window.rowsA;i++){
			var e = document.getElementById("one");
			e1=e.cloneNode(true);
			e1.value="";
			
			var input = e1.cloneNode(true);
			var divOne=window.cdivA.item(i);
			divOne.appendChild(input);
		};
		
		window.a = document.getElementById("aMatr");
		window.cdivA=window.a.getElementsByTagName("div");
		window.colsA=window.cdivA.item(0).getElementsByTagName("input").length;
		}
		else alert("Матрица А не может иметь больше 10 столбцов!");
	}
	else if (window.colsB<10){		
			for (var i=0;i<window.rowsB;i++){
			var e = document.getElementById("one");
			e1=e.cloneNode(true);
			e1.value="";
			var input = e1.cloneNode(true);
			var divOne=window.cdivB.item(i);
			divOne.appendChild(input);
		};
		
		window.b = document.getElementById("bMatr");
		window.cdivB=window.b.getElementsByTagName("div");
		window.colsB=window.cdivB.item(0).getElementsByTagName("input").length;
	}
	else alert("Матрица B не может иметь больше 10 столбцов!");
		
placeholder();
}

function getClass(obj) {        /* Получение типа из объекта*/
  return {}.toString.call(obj).slice(8, -1);
}

function delstolbec(){         /* Удаление столбца*/
	
	var k =document.getElementById("da");
	
	if (k.checked) {
		if (window.colsA>2) 
		{		
		for (var i=0;i<window.rowsA;i++){
			var divOne=window.cdivA.item(i);
			if (getClass(divOne.childNodes[window.colsA+2])=="Text"){
						lastcell=divOne.childNodes[window.colsA+3]}
					else {
						lastcell=divOne.childNodes[window.colsA+2];	
					}						
			divOne.removeChild(lastcell);
		};
		
		window.a = document.getElementById("aMatr");
		window.cdivA=window.a.getElementsByTagName("div");
		window.colsA=window.cdivA.item(0).getElementsByTagName("input").length;
		}
		else alert("Матрица А не может иметь менее 2 столбцов!");
	}
	if (k.checked==false) {
		if (window.colsB>2) 
		{		
		for (var i=0;i<window.rowsB;i++){
			var divOne=window.cdivB.item(i);
	
				
					if (getClass(divOne.childNodes[window.colsB+2])=="Text"){
						lastcell=divOne.childNodes[window.colsB+3]}
					else {
						lastcell=divOne.childNodes[window.colsB+2];	
					}
					
			divOne.removeChild(lastcell);
		};
		
		window.b = document.getElementById("bMatr");
		window.cdivB=window.b.getElementsByTagName("div");
		window.colsB=window.cdivB.item(0).getElementsByTagName("input").length;
		}
		else alert("Матрица B не может иметь менее 2 столбцов!");
	}
placeholder();
}

function placeholder(){      

		for (var i=0;i<window.rowsA;i++){
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			
			inputOne.item(j).placeholder="a"+(i+1)+","+(j+1);
			inputOne.item(j).disabled=false;
		}		
	};
	
	for (var i=0;i<window.rowsB;i++){
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			
			inputOne.item(j).placeholder="b"+(i+1)+","+(j+1);
			inputOne.item(j).disabled=false;
		}		
	};
	
	for (var i=0;i<window.rowsC;i++){
		var divOne=window.cdivC.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsC;j++){
			
			inputOne.item(j).placeholder="c"+(i+1)+","+(j+1);
			inputOne.item(j).disabled=true;
		}		
	};
}

function clearMatr()  
{	

	/*  Очистка матрицы А*/
	for (var i=0;i<window.rowsA;i++){
		var divOne=window.cdivA.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsA;j++){
			inputOne.item(j).value="";
		}		
	};
	/*  Очистка матрицы B*/
   	for (var i=0;i<window.rowsB;i++){
		var divOne=window.cdivB.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsB;j++){
			inputOne.item(j).value="";
		}
		
	};
	/*  Очистка матрицы C*/
	   	for (var i=0;i<window.rowsC;i++){
		var divOne=window.cdivC.item(i);
		var inputOne=divOne.getElementsByTagName("input");
		for (var j=0;j<window.colsC;j++){
			inputOne.item(j).disabled=false;
			inputOne.item(j).value="";
			inputOne.item(j).disabled=true;
		}
		
	};
		
}	
	
	